# Install

```
npm install
```
(this could take a few minutes)


# Run

In one console window, start up the project
```
npm start
```

after that starts, in a second console window open cypress
```
npx cypress open
```
OR
```
npm run cypress-open
```