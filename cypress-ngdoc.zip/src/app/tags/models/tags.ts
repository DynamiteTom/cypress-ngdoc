export interface ITag {
  _id: string;
  tag: string;
}
