
export interface IUser {
  google: {
    id: String,
    token: String,
  };
  email: String;
  name: String;
  role: String;
}
