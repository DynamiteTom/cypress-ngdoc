export interface IArticleFilter {
  keywords: string;
  tags: string[];
  version: string;
  showAllTags: boolean;
}
