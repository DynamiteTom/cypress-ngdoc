export const environment = {
  production: true,
  captcha_key: '6LfDuD0UAAAAAMn64Q9EJCSDF546oURHZY8JJFPg',
  captcha_secret: '6LfDuD0UAAAAAH_5oJonyd_ZoMB2-xmYl1euITgr'
};
