// The file contents for the current environment will overwrite these during build.
// The build system defaults to the dev environment which uses `environment.ts`, but if you do
// `ng build --env=prod` then `environment.prod.ts` will be used instead.
// The list of which env maps to which file can be found in `angular-cli.json`.

export const environment = {
  production: false,
  captcha_key: '6LfDuD0UAAAAAMn64Q9EJCSDF546oURHZY8JJFPg',
  captcha_secret: '6LfDuD0UAAAAAH_5oJonyd_ZoMB2-xmYl1euITgr'
};
